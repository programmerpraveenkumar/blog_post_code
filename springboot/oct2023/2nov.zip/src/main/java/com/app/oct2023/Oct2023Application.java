package com.app.oct2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oct2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Oct2023Application.class, args);
	}

}
