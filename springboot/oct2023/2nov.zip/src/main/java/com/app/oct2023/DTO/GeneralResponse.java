package com.app.oct2023.DTO;

public class GeneralResponse {
    private String message;
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
